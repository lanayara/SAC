package Controller;

import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

import org.json.JSONObject;

import Model.Controller;
import javafx.application.Platform;
import javafx.scene.control.Button;
import javafx.scene.control.Label;


public class getConnection extends Thread{
    //Assinando o objeto Socket da conexão
    Socket socket;
 
    Label labelAtencao;    Label labelMeditacao;    Label labelPiscar;    Button btnPiscou;                                     Label infoSensor;    Button btnDesconectar;     Controller controle = new Controller();
    
    public getConnection(Socket socket, Label status, Button btnDesconectar,
    	Controller con, Label labelAtencao, Label labelMeditacao, Label labelPiscar) {
        this.socket = socket;
        this.infoSensor = status;
        this.controle = con;
        this.btnDesconectar = btnDesconectar;
        this.labelAtencao = labelAtencao;
        this.labelMeditacao = labelMeditacao;
        this.labelPiscar = labelPiscar;
    }
    
    @Override
    public void run() {
        System.out.println("Recebendo dados!");
        
        //Inicia um la�o de repeti��o infinito que ser� utilizado para gerir os dados
        //de acordo com o que � recebido via socket
        while(true){
            try{
                
                //Cria um objeto Scanner para armazenar os dados recebidos na conex�o do socket
                Scanner scanner = new Scanner(this.socket.getInputStream());
                
                //Cria a varipavel que armazenar� os dados recebidos
                String mensagem = null;
                
                //verifica se o que foi recebido n�o est� vazio
                while (scanner.hasNextLine()) {
                    
                    //pega o que est� sendo recebido e armazena na vari�vel
                    mensagem = scanner.nextLine();
                    
                    //Cria um objeto JSON da mensagem
                    JSONObject json = new JSONObject(mensagem);
                    
                    /* RFEDRE-SE A FUN��O PISCAR DOS OLHOS*/
                    //verifica se no objeto JSON existe a chave "blinkStrength" que ser�
                    //respons�vel por armazenar o piscar dos olhos
                    
                    if(json.has("blinkStrength")){
                        //calculando a porcentagem do piscar
                        //80 � a base escolhida(32%)
                        float result = (json.getInt("blinkStrength") * 100) / 255;
                        
                        //verifica se a for�a do piscar � maior que 50
                        if(json.getInt("blinkStrength") >= 80){
                            System.out.println("Piscou!");
                            //controle
                            this.controle.setPiscou(true);
                        }
                        Platform.runLater(new Runnable() {
                            @Override public void run() {
                                labelPiscar.setText(String.valueOf( result + " %"));
                            }
                        });
                    }
                    
                    //verifica o sinal do sensor
                    if(json.has("poorSignalLevel")){
                        //�timo sinal
                        if(json.getInt("poorSignalLevel") < 5){
                            Platform.runLater(new Runnable() {
                                @Override public void run() {
                                    infoSensor.setText("Sinal �timo!"); }});
                        //Sinal Razo�vel
                        }else if(json.getInt("poorSignalLevel") > 20 && json.getInt("poorSignalLevel") < 50){
                            Platform.runLater(new Runnable() {
                                @Override public void run() {
                                    infoSensor.setText("Melhore o contato com o sensor!");}
                            });
                        }else{
                            //Sinal Fraco
                            Platform.runLater(new Runnable() {
                                @Override public void run() {
                                    infoSensor.setText("Sem contato com o sensor");}});}}
                    //Status da conexão
                    if(json.has("status")){
                        Platform.runLater(new Runnable() {
                            @Override public void run() {
                                //conexao.setText("Conectando...");
                            	}});
                    }else{
                        Platform.runLater(new Runnable() {
                            @Override public void run() {
                                btnDesconectar.setVisible(true);}});}
                    //dados do sensor
                    if(json.has("eSense")){
                        JSONObject esense = json.getJSONObject("eSense");
                        Platform.runLater(new Runnable() {
                            @Override public void run() {
                                labelAtencao.setText(String.valueOf( esense.getDouble("attention") ) + " %");
                                labelMeditacao.setText(String.valueOf( esense.getDouble("meditation") ) + " %");}});}
                }
            } catch (IOException ex) {
                System.out.println("Erro");
            } finally{
                try {
                    this.socket.close();
                    System.out.println("Fechou!");
                } catch (IOException ex) {
                    //
                }
            }
        }
        
    }
    public void close(){
        try {
            this.socket.close();
            System.out.println("Socket Fachado!");
        } catch (IOException ex) {
            System.out.println("Erro ao fechar socket!");
        }
    }
}
