/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Botao;
import Model.BtnOp;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;

public class ControllerPainel extends Thread {

    private ArrayList<Botao> botoes = new ArrayList<>();
    private ArrayList<BtnOp> opcoes = new ArrayList<>();
    private Model.Controller controller;
    private int totalBotoes;

    public ControllerPainel(Model.Controller controller, ArrayList<Botao> botoes, ArrayList<BtnOp> op) {
        this.botoes = botoes;
        this.controller = controller;
        this.totalBotoes = this.botoes.size();
        this.opcoes = op;
    }
    @Override
    public void run() {
        super.run();
        
        //inicia a varredura dos botões
        for(int indice = 0; indice < this.totalBotoes; indice++){
            this.limpaBotoes();
            this.limpaBtnOp();
            
            //Botão da vez
            Button botao = botoes.get(indice).getBotao();
            
            //altera a cor do botão
            botao.setBackground(new Background(new BackgroundFill(javafx.scene.paint.Color.rgb(246, 41, 7), CornerRadii.EMPTY, Insets.EMPTY)));
            try {
                //para no botão
                Thread.sleep(1500);
            } catch (InterruptedException ex) {
                Logger.getLogger(ControllerPainel.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            //verifica se piscou
            if(controller.isPiscou()){
                controller.setPiscou(false);
                //pega o valor do botão
                String fala = botoes.get(indice).getValor();
                //Voz
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException ex) {
                    Logger.getLogger(ControllerPainel.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                /*
                //altera para opções
                for(int o = 0; o < opcoes.size(); o++){
                    this.limpaBotoes();
                    this.limpaBtnOp();
                    Button bOp;
                    //pega o botão
                    bOp = opcoes.get(o).getBtn();
                    //limpa os botões
                    
                    bOp.setBackground(new Background(new BackgroundFill(javafx.scene.paint.Color.rgb(232, 42, 2), CornerRadii.EMPTY, Insets.EMPTY)));
                    try {
                        Thread.sleep(1500);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(ControllerPainel.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                    //verifica se poscou
                    if(controller.isPiscou()){
                        controller.setPiscou(false);
                        BtnOp btn = opcoes.get(o);
                        
                        //Reinicia
                        if(btn.getOp() == 1){
                            indice = -1;
                            break;
                        }
                        
                        //Pausa
                        if(btn.getOp() == 2){
                            indice = -1;
                            break;
                        }
                        
                        //Fechar
                        if(btn.getOp() == 3){
                            System.out.println("Fechando Aplicativo");
                            System.exit(0);
                            break;
                        }
                        
                    }
                    
                    if(o == (opcoes.size() - 1)){
                        o = -1;
                    }
                }
                */
            }
            
            
            //Verificação do último valor
            if(indice == (totalBotoes - 1)){
                indice = -1;
            }   
        }       
    }    
    
    /*ALTERANDO TODOS OS BOTÕES PARA PADRÃO*/
    private void limpaBotoes(){
        for(int i = 0; i < totalBotoes; i++){
            Button b = botoes.get(i).getBotao();
            b.setBackground(new Background(new BackgroundFill(javafx.scene.paint.Color.rgb(246, 251, 255), CornerRadii.EMPTY, Insets.EMPTY)));
        }
    }
    
    //limpa os botões de opções
    private void limpaBtnOp(){
        for(int i = 0; i < opcoes.size(); i++){
            Button b = opcoes.get(i).getBtn();
            b.setBackground(new Background(new BackgroundFill(javafx.scene.paint.Color.rgb(32, 185, 232), CornerRadii.EMPTY, Insets.EMPTY)));
        }
    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.
        this.stop();
    }
    
    
    
    
    
}
