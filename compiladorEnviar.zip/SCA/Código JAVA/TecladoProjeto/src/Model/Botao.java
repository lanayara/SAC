package Model;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class Botao {
    private Button botao;
    private String valor;
    private VBox painel;
    
    public Botao(String frase, VBox painel){
        this.painel = painel;
        this.botao = new Button(frase);
        this.botao.setFont(new Font("Arial", 18));
        this.botao.setBackground(new Background(new BackgroundFill(javafx.scene.paint.Color.rgb(246, 251, 255), CornerRadii.EMPTY, Insets.EMPTY)));
        //alterando o tamanho do botão
        this.botao.setMinSize((this.painel.getPrefWidth() - 100), 50);
        this.valor = frase;
    }

    public Button getBotao() {
        return botao;
    }

    public void setBotao(Button botao) {
        this.botao = botao;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }
    
    
    
}
