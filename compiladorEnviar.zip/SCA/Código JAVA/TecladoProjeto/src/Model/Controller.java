package Model;

public class Controller {
    
    private boolean piscou;

    public Controller() {
        this.piscou = false;
    }

    public void setPiscou(boolean piscou) {
        this.piscou = piscou;
    }

    public boolean isPiscou() {
        return piscou;
    }
    
}
