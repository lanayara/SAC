package Model;
import javafx.scene.control.Button;
public class BtnOp {
    private Button btn;
    private int op;

    public BtnOp(Button btn, int op) {
        this.btn = btn;
        this.op = op;
    }

    public Button getBtn() {
        return btn;
    }

    public void setBtn(Button btn) {
        this.btn = btn;
    }

    public int getOp() {
        return op;
    }

    public void setOp(int op) {
        this.op = op;
    }
    
    
    
}
