package tecladoprojeto;

import Controller.ControllerPainel;
import Controller.getConnection;
import Model.Botao;
import Model.BtnOp;
import Model.Controller;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import org.json.JSONObject;

public class FXMLDocumentController implements Initializable {
    private Socket conexao;
    private ArrayList<Botao> botoes = new ArrayList<>();
    private ArrayList<BtnOp> opcoes = new ArrayList<>();
    private int porta = 13854;
    private String ipServidor = "127.0.0.1";
    private getConnection con;
    private ControllerPainel painelController;
    private Model.Controller controle;
    
    @FXML
    private Label labelStatus;@FXML private Button btnConectar;     @FXML     private Button btnDesconecta;     @FXML     private Label labelMeditacao;    @FXML     private Label labelAtencao;     @FXML     private Label labelPiscar;     @FXML     private VBox painelFrases;     @FXML     private VBox painel2;    @FXML
    void DesconectarSocket(ActionEvent event) {
        try {
            this.conexao.close();
            this.con.close();
            this.con.stop();
            this.btnDesconecta.setVisible(false);
            this.painelController.stop();
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.btnConectar.setDisable(false);
    }

    @FXML
    void conectaSocket(ActionEvent event) {
        this.btnConectar.setDisable(true);
        try{
            //abre a conex�o com o ThinkGear
            this.conexao = new Socket(ipServidor, porta);
            //envia dos dados para o socket
            this.enviaDados();
            
            //verifica os dados recebidos no socket
            this.con = new getConnection(conexao, labelStatus, btnDesconecta, controle,
            		labelAtencao, labelMeditacao, labelPiscar);
            //inicia a verifica��o
            this.con.start();
            
            this.painelController = new ControllerPainel(controle, botoes, opcoes);
            this.painelController.start();
            
        } catch(IOException ex){
            System.out.println("Erro ao abrir conexão");
            this.alert(1, "Verifique se o ThinkGear Connector est� dispon�vel!");
            this.btnConectar.setDisable(false);
        }
    }
    
    private void enviaDados() throws IOException{
    	
        //gerencia o envio das informa��es via socket
        OutputStreamWriter out = new OutputStreamWriter(this.conexao.getOutputStream());
        
        //escreve as informa��es a serem enviadas
        out.write(this.getAuto().toString());
        
        //Envia os dados
        out.flush();
   }
    private JSONObject getAuto (){
        JSONObject retorno = new JSONObject();
        
        retorno.put("appName", "MindWave e Java");
        
        //Chave do aplicativo
        retorno.put("appKey", "9f54141b4b4c567d559d3a76cb8d715cbde03096"); 
        
        //deseja receber os dados brutos do sensor?
        retorno.put("enableRawOutput", true);
        
        //define o formato de comunica��o entre o ThinkGear Connector e o programa
        retorno.put("format", "json");
        
        System.out.println(retorno.toString());
        
        //retorna o JSON
        return retorno;
    }
    
    private void alert(int tipo, String msg){
        switch(tipo){
            case 1:
                Alert alerta1 = new Alert(Alert.AlertType.ERROR);
                alerta1.setTitle("Erro");
                alerta1.setContentText(msg);
                alerta1.show();
                break;
            case 2:
                Alert alerta2 = new Alert(Alert.AlertType.INFORMATION);
                alerta2.setTitle("Informa��o");
                alerta2.setContentText(msg);
                alerta2.show();
                break;
            default:
        }
    }
    
    private void addBotao(String frase){
        Botao b = new Botao(frase, painelFrases);
        if(botoes.size() >= 7){
            painel2.getChildren().add(b.getBotao());
        }else{
            painelFrases.getChildren().add(b.getBotao());
        }
        botoes.add(b);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.controle = new Controller();
        this.addBotao("N�O ENTENDI");
        this.addBotao("PODE REPETIR?");
        this.addBotao("COM LICEN�A");
        
        btnDesconecta.setVisible(false);
        
    }    
    
}
